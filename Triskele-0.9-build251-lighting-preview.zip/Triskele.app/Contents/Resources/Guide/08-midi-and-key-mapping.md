# MIDI and key mapping

Put any knob, fader, pad or key on the controls you use most, the way Ableton Live does it: switch a map mode on, click a control, then move the knob or press the key. Mappings are saved with the show.

## Mapping something

1. Turn on **MIDI Map Mode** (**⇧⌘M**, Setup → MIDI Map Mode, or **MIDI** at the top right of the lighting window). Everything you can map turns **blue**, and the **MIDI & Key Mappings** window opens.
2. **Click a control**: a group or palette tile, a key, a selection tool, an encoder knob, the grand master, a blackout, the lighting Go or Back, the sound or video master, Oh No!. It gets a white frame.
3. **Move a knob or fader, or hit a pad** on your controller. That's it: the control shows what it's mapped to (CC 21, C3…). Click the next control and carry on.
4. Turn the mode off again to play.

**Key Map Mode** (**⇧⌘K**, or **KEY**) is the same with the Mac's keys: controls turn **red**; click one, press a key. A mapped key works whenever you're not typing in a text field, and comes before cue hotkeys. Space is always GO, so it can't be mapped.

Controls with nothing on screen to click (GO, Pause All, Resume All…) are in **Map a Show Control** in the mappings window.

One knob, pad or key drives one thing, and each control has one MIDI mapping and one key; mapping again replaces the old one.

## What a mapping does

- **Pads and keys** on tiles and keys press them, just like clicking (with **ADD** or **REMOVE** pressed first, a group pad adds or takes away; with **REC**, it stores).
- **Faders and knobs** on the masters and on encoders set the value. On an encoder (pan, tilt, zoom…) they set the selected lights.
- **Endless encoders** (knobs that turn forever) send steps, not positions. In the mappings window, pick the kind your controller sends: Bin Offset, Twos Complement, Signed Bit or Signed Bit 2 (if it moves the wrong way or jumps, try another).

## The mappings window

Setup → **MIDI & Key Mappings…** lists every mapping: what drives it, what it drives, and for faders and knobs:

- **Min** and **Max**: the part of the range the fader covers (a fader that only goes from 20% to 80%). The ⇄ button swaps them, so the fader works upside down.
- **Takeover**, for when the fader doesn't match the value (it was changed on screen, or the fader was moved while doing something else):
  - **Pick up** (the default): nothing happens until the fader passes the value, so nothing jumps;
  - **Jump**: the value jumps to the fader at once;
  - **Catch up gradually**: the value moves towards the fader as you move it, and they meet at the end.
- The bin deletes a mapping.

Mappings are kept with the show, so a show carries its controller layout with it.

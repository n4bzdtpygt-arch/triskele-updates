# Keyboard shortcuts

| Key | What it does |
|---|---|
| Space | Ah Go On! (fire the standby cue) |
| Esc | Oh No! (fade everything out; again to stop dead) |
| ↑ / ↓ | Move the standby |
| → / ← | Open / close a group or a cue's waveform |
| ⌘P / ⇧⌘P | Pause all / resume all |
| ⌘D | Devamp everything looping |
| ⌘L | Load the standby cue to a time |
| ⇧⌘A | Audition the standby cue on headphones |
| ⇧⌘B | Projector blackout |
| ⌥⌘B | Blind |
| ⌥⌘L | Lock for performance |
| ⌥⌘R | Ready Check |
| ⌥⌘N | New cue list |
| ⌘I | Simple inspector |
| ⌥⌘P | Projection mapping |
| ⌥⌘K | Speakers (tuning and room) |
| ⌥⌘J | Lighting |
| ⌘Z / ⇧⌘Z | Undo / redo |
| ⌘C / ⌘X / ⌘V | Copy / cut / paste cues |
| ⌘S / ⇧⌘S / ⌥⇧⌘S | Save / Save As / Save as Bundle with Media |
| A cue's hotkey | Fires that cue without moving the standby |
| ⌘? | Triskele Help (this guide, searchable) |
| ⌘, | Settings |
| ⌃⌘S / ⌃⌘V | New Sound / Video or Picture cue (choose files) |
| ⌃⌘T / ⌃⌘M / ⌃⌘C | New Text / Mic / Camera cue |
| ⌃⌘E | New Fade cue, aimed at the standby (⌃⌘F stays macOS full screen) |
| ⌃⌘1 … ⌃⌘7 | New Start, Stop, Pause, Go To, Wait, Memo, Load cue |
| ⌘G / ⇧⌘G | Group the selected cues / ungroup |
| ⇧⌘D | Duplicate |
| ⌃⌘R | Renumber Cues… |
| ⇧↩ | Fire the selected cues now (the standby doesn't move) |
| ⌥⌘S | Stage preview panel |
| ⌥⌘C | List / Cart |
| ⌥⌘O | Open the video outputs |
| ⌥⌘T | Speaker & Projector Check |
| ⌥⌘U | Surfaces |

In the list: drag a wait up/down (⌥ fine, ⇧ coarse), double-click a name, cue line or level to type it.
In the lighting timeline: ⌥-drag for hundredths, ⇧-drag for whole seconds.

# Triskele user guide

1. [Getting started](01-getting-started.md)
2. [Sound](02-sound.md)
3. [Video and projection mapping](03-video-and-mapping.md)
4. [Lighting](04-lighting.md) (not in this beta)
5. [Running the show](05-show-day.md)
6. [Show control: MIDI, OSC, timecode, phone remote](06-show-control.md)
7. [Keyboard shortcuts](07-keyboard.md)

Things found while writing this guide that need fixing or deciding are in [issues-found.md](issues-found.md).

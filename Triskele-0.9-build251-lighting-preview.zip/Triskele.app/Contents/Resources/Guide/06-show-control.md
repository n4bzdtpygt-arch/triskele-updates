# Show control: MIDI, OSC, timecode and the phone remote

Everything here is in **Setup → MIDI, OSC, Timecode & Phone Remote…**

## Being fired by other gear

- **MIDI Show Control**: GO, GO n, STOP, RESUME, ALL OFF and RESET, from any device ID or one you choose.
- **MIDI Program Change** n fires cue n.
- **OSC over the network**: `/go`, `/stop` (Oh No!), `/pause`, `/resume`, `/cue/12/go`, `/cue/12/stop`, `/cue/12/load 30.5`.

A light in the transport bar shows what arrived, and from which device ("MSC GO cue 12 from ETC Gadget"). If a desk asks for a cue the show doesn't have, Triskele says which device asked and how to fix it; while the show has no cues at all it just notes it in the show log. These work when the show is locked. "GO 12" moves the standby to cue 12 and fires it, so the desk and Triskele stay in step.

## Telling other gear what happened (broadcast)

Turn on **Broadcast** and Triskele sends OSC (`/triskele/go "12" "name"`, `/triskele/standby`, `/triskele/stopall`, `/triskele/pause`, `/triskele/resume`) and, if you like, MSC GO n on each GO. Oh No! is never sent as MSC, so it can't black out a lighting desk.

## Sending messages from a cue

- **MIDI** cue (cue-type strip): MSC GO / STOP / RESUME / ALL OFF, Program Change or Note On, to every MIDI output or one you choose.
- **OSC** cue: host, port, address and one argument.
- **From a Template**: ready-made messages for ETC Eos, Behringer X32 / Midas M32, Allen & Heath Qu/SQ, Yamaha CL/QL/TF, other show-control software and another Triskele. (Check them against your desk: they haven't been tried on real desks yet.)

## Timecode

- **Follow timecode**: choose MTC or LTC (an audio input and channel) and the frame rate. Give any cue a **Timecode** time in its Timing panel; it fires when the timecode passes that time. Jumps and running backwards fire nothing.
- **Send timecode**: a **Timecode** cue sends LTC on an audio output or MTC to a MIDI output, from a start time, until it's stopped.

## Phone remote

Turn on the **phone remote**, then scan the QR code on a phone or tablet on the same Wi-Fi and enter the PIN. You get the standby cue and its notes, what's playing, and buttons for **Ah Go On!**, **Oh No!**, Pause, Resume, Blackout and Apply Changes. Five wrong PINs in a minute lock it out for a minute.

# Getting started

Triskele (said "TRISS-keel", after the triple spiral: sound, video and light as one) runs a show from one cue list: sound, video and lighting cues in the order you'll fire them, each fired with one key.

> **This is a beta**: a test version, shown by the **BETA** chip beside the standby card and in **Triskele → About Triskele**, which also gives the build number. Please report anything that goes wrong, with the show log (**Setup → Open Today's Show Log**).

## Install and open

1. Unzip **Triskele.zip** and drag **Triskele.app** into Applications.
2. Double-click it. The first time, macOS checks it and asks whether to open an app downloaded from the internet: click **Open**.
3. Accept the licence agreement. You get a 30-day trial; after that shows still open and play, but you can't edit or save without a key (**Triskele → Licence…**).

## The window

- **Cue list** (middle): every cue in firing order. The **standby** cue has a yellow edge: it's the one the next GO fires.
- **Standby card**: the standby cue's number, name, cue line and notes, large enough to read in the dark.
- **Cue-type strip** (beside the list tabs): every kind of cue you can add, each named under its icon (icons only when the window is narrow). Hover over one to see what it does.
- **Inspector** (bottom): the settings of the selected cue, in tabs. Drag its top edge to resize; **⌘I** shrinks it to one line.
- **Transport bar**: the sound master, output meters, what's arrived from MIDI/OSC, and the red **Oh No!** button.
- **Toolbar**: Add Media, List / Cart, Stage (video preview), Mapping, Lighting, Speakers, Blind (eye) and Lock, each with its name.

## Your first show in two minutes

1. **Add sounds.** Drag sound files (or a whole folder) from the Finder into the list, or click **Sound** in the cue-type strip. Each file becomes a cue, and the standby stays on cue 1, so the first Space fires it. (**Add Without a File** in that picker adds a cue whose file comes later.)
2. **Put them in order.** Drag rows up and down. Drop a file *on the middle* of a sound cue to replace its file; on the edges to insert.
3. **Fade one out.** Select a playing cue and click **Fade** in the strip: a fade cue aimed at it is added just after it (3 s to silence, then stop). Drag a different cue onto the fade to change what it fades.
4. **Run it.** Press **Space** (Ah Go On!) to fire the standby cue; the standby moves to the next one. Press **Esc** (Oh No!) to fade everything out; Esc again stops dead.
5. **Save.** **⌘S** saves a `.triskele` file. (Shows saved while it was called CueDeck, `.cuedeck` and `.cuedeckbundle`, still open; saving writes the new type.) To move a show to another Mac with its media, use **File → Save as Bundle with Media…** (⌥⇧⌘S).

## Ideas worth knowing on day one

- **Settings in one place.** **Triskele → Settings…** (⌘,) has Audio, Video, Lighting, Show Control and General. Each part says where it's kept: **with the show** (it travels in the show file), **with the venue** (the room's projectors, mapping and speakers) or **this Mac only**.
- **Cue numbers look after themselves.** New cues get the simplest free number between their neighbours (6 between 5 and 7; 5.1 between 5 and 6). **Cues → Renumber Cues…** gives clean whole numbers again.
- **Click or drag gives the same result.** Clicking a Fade, Stop or Start in the strip aims it at the selected cue; dragging it aims it at the cue you drop it on.
- **Everything is undoable** (⌘Z), including deletes and pastes.
- **Hidden until hovered.** Zero waits, "do not continue" arrows and 0 dB levels are hidden in the list so it stays calm; hover a row to see them.
- **Booth light.** **View → Booth Light** dims every window for a dark control room.
- **Light or dark.** **View → Appearance**: Dark (Booth) is the default, made for a dark control room; Light puts the same colours on the painting's pale linen, for programming in daylight; Match the Mac follows the system setting.

## Help inside Triskele

This guide is built in: **Help → Triskele Help** (⌘?) opens it, with a search box at the top. The small **(?)** buttons around the app open it at the part that explains what's next to them. **Help → Send Feedback…** starts an email to us with today's show log attached (it lists the cues you ran today, nothing else from your Mac).

## Where to go next

- [Sound](02-sound.md): levels, trims, loops, routing, fades, ducking, placing sounds in the room.
- [Video and projection mapping](03-video-and-mapping.md)
- [Lighting](04-lighting.md)
- [Running the show](05-show-day.md): lock, blind, Ready Check, backups, what to do when things go wrong.
- [Show control](06-show-control.md): MIDI, OSC, timecode, the phone remote.
- [Keyboard shortcuts](07-keyboard.md)

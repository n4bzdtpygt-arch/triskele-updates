# Video and projection mapping

## How video works in Triskele

Every picture is drawn onto one **stage** (1920 × 1080 unless the venue sets another size). Each projector or screen (an **output**) then shows its part of the stage, warped and blended to fit the surface. You build the show on the stage; you fit the stage to the room in the **mapping editor**. The mapping belongs to the **venue**, not the show. A venue is the room's setup: projectors, mapping and speaker tuning. Your cues stay the same when you change venue, so a touring show only needs re-mapping in a new space. The mapping window's sidebar draws the stage with each projector's part of it, and shades the strips where two projectors blend into one picture.

## Video, picture and text cues

- **Video**: drag movies in, or click **Video** in the cue-type strip. A movie's soundtrack plays through the sound system, so it can be routed, faded and placed like any sound.
- **Pictures**: drag still images in. A PNG's transparent parts show what's underneath. A picture shows until it's stopped or faded out.
- **Text**: click **Text** in the strip; set the words, font, size, alignment and colour in its Text tab.
- **Camera**: click **Camera** to show a live camera or capture card. It behaves like a picture.

Cues lower in the list draw on top of those above them.

Video and picture cues show a **thumbnail** in the list. A movie's **Trim & Loop** tab has its pictures along a strip over the soundtrack: move the mouse along to see each moment (⇧-drag to scrub with sound on headphones). A small **stage monitor** beside the standby card shows what the stage is showing now (**View → Output Monitor** hides it).

## The Picture tab

- **Fit / Fill / Stretch / Actual size**: how the picture fills the stage.
- **Position, scale, rotation, crop** and **opacity**.
- **Surface**: fit the picture into a named area of the stage. Pick a surface, not a projector: the picture lands on that part of the stage, whichever projectors cover it, and still lands there in another venue.

## The Effects tab

Video, picture, text and camera cues have an **Effects** tab, drawn live on the stage by the graphics card:

- **Looks**: Black & White, Old Film, Dream, Night, Out of Focus, Green Screen, Blue Screen: ready-made starting points.
- **Brightness, Contrast, Saturation** (0 = black and white), **Hue** (round the colour wheel), **Sepia**, **Blur** (in stage pixels) and **Vignette** (darker towards the edges). Double-click a slider to reset it; **Reset** puts everything back.
- **Colour key**: takes one colour out, so what's below shows through (a performer filmed in front of a green or blue screen over a video). Pick the **key colour**, then widen **Tolerance** until the screen is gone and soften the edge with **Softness**.

Changes show at once while the cue plays (a short slide, no jump), and in Blind they wait like any other edit. A fade cue can fade every value (below).

## Surfaces

Every projector has a surface of its own, named after it, and every set of projectors blended together gets one too (**Main screen**, or Screen 1, Screen 2… when there are several). They follow the projectors: move a projector's stage area or rename it and its surface follows. They're matched by position (the first projector, the first blended screen), so a show taken to another venue lands on that venue's first projector and main screen. Make your own in **Setup → Surfaces…** for anything else: a flat, the cyc, a window.

## Stage preview

Click **Stage** in the toolbar for a live view of the stage. Every picture has an outline; click one to select its cue, drag to move it (⇧ keeps it on one axis), ⌥-drag to scale. A see-through "ghost" shows the selected cue even when it isn't playing (turn it off in **View → Ghost in Stage Preview**).

## Fading and moving pictures

A fade cue aimed at a video or picture fades its **opacity** (and soundtrack level). Turn on **Geometry** in a fade cue to move, scale or rotate the picture over the fade time instead. Turn on **Effects** to fade the picture's effects to the values set in the fade cue's own **Effects** tab: drift into black and white, blur a picture out of focus, bring a key in. The cue's own effects come back at its next GO.

## Video outputs

The Video Output window opens by itself when a video cue fires: full screen on a second display if there is one, otherwise a preview window. **Setup → Video Outputs** opens, closes and identifies them. **Projector Blackout** (⇧⌘B) turns every projector black while cues keep running.

## Projection mapping

Open the mapping editor with **Mapping** in the toolbar (or ⌥⌘P).

1. **Outputs.** Add an output for each projector and choose its display. "Side by Side" sets up 2–4 projectors sharing one wide picture.
2. **Stage area.** In **Warp** mode, the stage panel shows a box for each projector's part of the stage; drag it to move it, or its edges to resize it.
3. **Warp.** Turn on **Test** to show a grid on the projectors, then drag the points until the grid fits the surface. A 2 × 2 grid is a corner pin; up to 9 × 9 bends the picture onto curved or uneven surfaces. Arrow keys nudge a point; double-click resets it. With **Points on projector** on, you can drag the points on the projector's own window.
4. **Blend.** Where two projectors overlap, set the blend width on each edge, then adjust curve and gamma until the overlap is invisible, and **black level** to hide the brighter strip where both projectors' black adds up.
5. **Masks.** Click **Mask**, then click round the shape you want to keep (or hide). Close it by clicking the first point, double-clicking or pressing Return. Masks can have soft edges and be curved. **All Masks Off** is a quick check if an output goes unexpectedly black.
6. **Colour.** Match projectors with brightness and red/green/blue gain.
7. **Mirror** an output for rear projection or a projector hung upside down.
8. **Slices.** Up to 8 extra pictures per projector, each from its own part of the stage with its own warp.

Every term has a **(?)** beside it that explains it in a sentence. **Undo** (and Redo) sit in the window's header and name what they'll undo; **Reset Warp** puts every point back on an even grid, and Undo brings your warp back.

**Auto-Align** (the camera button in the mapping header) uses a camera: the projector shows dots one at a time, the camera finds them, you drag four corners in the camera view, and the warp is worked out for you.

- **Use your iPhone (best results).** Its lens is far straighter than a webcam's, it holds focus and exposure steady, and it sees more detail. Same Apple ID on the iPhone and the Mac, Wi-Fi and Bluetooth on, the iPhone on a stand in landscape near the Mac (back camera facing the stage), then choose it in the Camera menu.
- **Where the camera goes:** where the audience sees from (central, middle rows, eye height), straight on, seeing the whole projection. Darken the room and don't move it between Measure and Align.
- **Focus, exposure and white balance** are held steady while the dots are measured, where the camera allows it.
- **Lens correction.** Webcams bend straight lines, which puts the warp off. Measure once on something flat (a wall or a flat screen) and click **Calibrate Lens from This Measurement**: every measurement with that camera is corrected from then on. With 2 × 2 (flat) chosen, an uncalibrated camera is calibrated automatically.
- **How good it is:** after Measure, the sheet says how many dots were found, how much the rows still bend and how well a flat surface explains them (in pixels of a 1080-line picture: under 3 is good). On a curved surface the flat fit is larger, which is expected.

**Stage size.** **Settings → Video → Stage size** (or **Change…** under the stage diagram in the mapping sidebar) sets the venue's stage in pixels: 3840 × 1080 for two projectors blended side by side, 5760 × 1080 for three, 3840 × 2160 for 4K, or any size you type. Triskele suggests a size when the projectors would be stretched. Pictures keep their size in pixels, so use Fit, Fill or a surface to fill a bigger screen.

**Venues** are saved on the Mac, separately from shows. Export one to bring it to another Mac, or import a venue someone sent you.

## Alignment patterns

The **Test** button's picker has: grid, crosshairs, convergence lines in each projector's colour, white, 50% grey and black.

## If a projector shows nothing

Check the red banner in the mapping editor ("Output shows nothing"): usually the main picture is turned off and there are no slices. **Turn the Picture On** fixes it. A small mask that keeps only its inside can also black out the whole output: try **All Masks Off**.

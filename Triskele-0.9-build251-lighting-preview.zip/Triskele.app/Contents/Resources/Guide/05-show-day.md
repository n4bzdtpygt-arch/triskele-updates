# Running the show

## Before the house opens

1. **Ready Check** (**Show → Ready Check…**, ⌥⌘R) checks, warnings first:
   - missing media
   - whether the show's audio interface is connected, and cues routed to outputs it doesn't have (the **Sound goes to** menu at the top lets you change it there)
   - whether each projector's display is connected, or an output is showing nothing
   - media on external drives, free disk space, battery
   - unsaved changes, held changes, files that changed on disk
   - double-GO protection
   It ends with tips (turn on Do Not Disturb) and a **Lock for Performance** button. Most rows have a button that fixes them: **Save**, **Lock**, **Reset Masters**, **End Blackout**, **Relink from Folder…**, **Audio Settings…**, **Turn On Do Not Disturb…** (opens Focus settings: apps can't switch it on themselves). When sound goes over **HDMI or DisplayPort** it reminds you to run the speaker check: a display's audio can be connected and still silent.
2. **Setup → Speaker & Projector Check…**: pink noise on each output; a test grid and Identify on each projector.
3. **Lock for Performance** (⌥⌘L, or the padlock in the toolbar): editing is switched off, but Ah Go On!, Oh No!, pause, hotkeys, the cart, Load and audition still work. Unlocking asks first. Locking also clears undo, so nothing can be undone by accident.

## Running

- **Space: Ah Go On!** Fires the standby cue. Holding Space never fires twice, and a second press within the **double-GO protection** time (0.25 s by default) is ignored.
- **Esc: Oh No!** Fades everything out over the Oh No! fade time (set it with the arrow on the red button: at once to 10 s). Press it again to stop dead. It never touches the lights.
- **⌘P / ⇧⌘P**: pause and resume everything (fades and waits hold too).
- **↑ / ↓** move the standby. Clicking a row also makes it the standby.
- **Hotkeys**: give a cue a single key (Hotkey field in the inspector header) to fire it without moving the standby.
- **Cart** (toolbar List / Cart): every cue as a tile. Click to fire, click again to stop.
- **Load to Time** (⌘L): start the standby cue part of the way in ("1:20"), for rehearsing from the middle.

### Colours in the list
Green is playing, orange is in its pre-wait, yellow is paused, red is fading out to stop, amber is loaded to a time, and a grey tick means already played (**Show → Clear Played Marks** clears them).

### Masters
The **sound master** is in the transport bar. **Projector Blackout** (⇧⌘B) blacks out every projector while cues keep running. **Show → Reset Masters** puts both back.

## Blind: changing a show while it runs

**Blind** (⌥⌘B, the eye in the toolbar) lets you edit without anything on stage changing. Edited cues get a blue dot and play their new settings from their next GO. When you leave Blind, choose **Apply Now** (a short ramp) or **Wait for Next GO**.

To hold changes for just one cue while the rest stay live: right-click it → **Hold Changes**. The standby card then says "N changes waiting"; click it to see what changed, hear it on headphones, and Apply it over a fade or Discard it.

## Multiple cue lists

The tabs above the list hold separate cue lists (+ to add, double-click to rename). Each keeps its own standby; GO acts on the list shown.

## If something goes wrong

- **The audio interface is unplugged:** when it's plugged back in, Triskele switches back to it by itself (straight away if no sound is playing or the show had gone silent, otherwise as soon as the sounds stop; pictures and silent loops don't hold it up). While the show is **locked**, sound goes silent in the meantime rather than coming out of the Mac's own speakers; Ready Check says "Sound is off". Unlock, or choose another output, to hear the Mac instead.


- **DISK ALMOST FULL** (red, by the standby card): less than 2 GB free. Saving, backups and the show log need room, so clear some space.

- **Media missing** (a badge on the cue): right-click → Relink, or **File → Relink Missing Media from Folder…** to fix every missing cue at once.
- **Interface unplugged**: sound switches to the Mac's own output and carries on; plug back in and it returns.
- **A file changed on disk**: a stopped cue reloads by itself; a playing one gets an amber ↻ and reloads once it stops.
- **Triskele quit unexpectedly**: next time it opens it offers to reopen the show at the standby cue, or its newest backup if it had unsaved changes.

## Backups and logs

**Reopening:** quit Triskele normally and it opens the same show next time, on the same cue list and standby cue (unless you open another by double-clicking it). After a crash it offers to reopen the show at the standby cue.

**Updates:** Triskele checks for a new version once a day and asks before installing it (Triskele → Check for Updates… checks now). It never checks while the show is locked or anything is playing, so an update window can't appear during a show.


- **Backups** are made every 2 minutes while the show changes, each time you save, and before New/Open. **File → Backups…** opens one as a new untitled show. 50 are kept per show.
- The **show log** is a diary of every GO, stop and message, per day: **Setup → Open Today's Show Log**.

## Moving to another Mac or venue

- **File → Save as Bundle with Media…** copies the show and every file it uses into one package.
- Projection mapping and speaker tuning belong to the **venue** (saved on the Mac). Export the venue from the mapping editor to take it with you, or set up a new venue in each new room.

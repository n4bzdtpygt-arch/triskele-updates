# Issues found while writing the guide (18 Nov 2026)

Writing each page meant checking the app does what the page says. These are the places where it didn't, or where explaining it showed something confusing. Most serious first.

## Bugs

1. **Fixed:** clicking **Light** in the cue-type strip made an old-style "Light Stack" control cue; dragging it made a proper Light cue. Clicking now makes a Light cue too.
2. **Fixed:** projection mapping was ⌥⌘M, which is the Mac's "Minimize All" windows; it's ⌥⌘P now (checked 21 Nov 2026).
3. **Fixed:** the debug window photographer found no main window: files given on the command line make macOS treat the launch as "open these documents", so SwiftUI skipped the main window. It now hosts one itself. (A normal launch was never affected.)

## Confusing or hard to find

4. **Fixed:** Oh No! still never touches the lights, but the main window now has a **Light** master and blackout in the transport bar (when lights are patched) and **Show → Lighting Blackout** (⌥⇧⌘B). Reset Masters resets it too.
5. **Fixed:** Pause All now holds lighting fades as well, and Resume All carries them on.
6. **Fixed:** the Look tab now lists **Lights in this cue** (level, palettes, what's set) with a button to take a light out.
7. **Fixed:** speaker tuning and room placement were under Show → Video Outputs → Speakers… (and greyed out with no video). Now a **Speakers** button sits next to Mapping in the toolbar, and Setup → Speakers… has its own menu item.
8. **Fixed:** the Show menu had about 30 items. Now **Show** is for running the show (Ah Go On!, Oh No!, pause, devamp, Load to Time, Blind, Lock, audition, blackouts, Ready Check), **Cues** for building it (new cue list, renumber, numbering from names, loudness, watching media) and **Setup** for windows, settings and logs (Lighting, Speakers, Video Outputs and Mapping, audition output, double-GO protection, Surfaces, MIDI/OSC, Speaker & Projector Check, logs).
9. **⌘D is Devamp.** QLab users may expect ⌘D to duplicate a cue (here Duplicate is right-click only).
10. **Naming isn't consistent yet:**
    - GO is "Ah Go On!" in the menu and remote, but help texts still say "GO" in many places.
    - The show log still says GO and STOP ALL.
    - Fixed (21 Nov 2026): "Goto" in the Load cue's help now says "Go to", like everything else.
    Decide how far the new names should go (desk messages like MSC "GO 12" must stay).
11. **Fixed:** Ready Check now covers lighting (DMX output off, patched universes not being sent, send errors, lights with no address, lighting blackout or master down) and warns about a projector blackout or sound/video master left down after rehearsal (it didn't before).
12. **Fixed:** the lighting cue list's Release takes the live cue's fade out time, and pulling its level to zero releases it.
13. **Fixed (21 Nov 2026):** the Sound and Video file picker has **Add Without a File**: the cue keeps its place, number, name and timing, says "No file yet", GO skips it and Ready Check lists it; right-click → Choose File…, or drop a file on the middle of the row.
14b. **Handled:** cues squeezed between 1 and 1.1 still get numbers like 1.0.1 (there's no number between them otherwise, and renumbering other cues by itself would break numbers a desk relies on), but Triskele now says so and points to Cues → Renumber Cues…. The usual cause: grouping cues 2 and 3 puts the group before cue 2, so it becomes 1.1.
14. **Speed changes only apply at the cue's next GO** (changing it mid-play would throw off its clock, auto-follow and loop ends). Since 21 Nov 2026 the Sound tab says so while the cue plays at another speed ("Playing at 100% now: the new speed starts at its next GO").

## Not yet possible (the guide has to say so)

15. Video cues can't vamp with an outro or change speed.
16. No video effects, and no NDI or Syphon.
17. Lighting effects are in (dimmer, flicker, pan, tilt, circle, rainbow, between palettes, and FX palettes), with a fixture library (Open Fixture Library plus GDTF import) and fanning. Still missing: effects on beam attributes and a tap-tempo / audio BPM.

## Spotted since

18. **Fixed:** the lighting inspector showed every beam slider (9 for a moving head). Now only the ones changed (or away from their resting value) show; the rest fold under "More (n)".
19. **The disk on this Mac was full** (about 150 MB free) during the build, which broke code signing. Now Triskele checks every minute and shows a red **DISK ALMOST FULL** chip by the standby card under 2 GB (and logs it). The space itself still needs clearing on this Mac.
20. **Fixed:** a recorded effect's knobs, waveform and palettes can now be changed straight in the Light cue's Look tab (live, keeping its place in the cycle).

## Never tried on real equipment (each guide page warns where it matters)

- An audio interface with more than 2 outputs.
- Real projectors: full screen on a second display, blending two projectors, camera auto-align.
- A real lighting rig over Art-Net or sACN.
- Real desks: MSC, OSC templates, LTC from another machine.
- A real mic and camera.

## For the guides themselves

- They need pictures: a screenshot of the main window with labels, the mapping editor, and the lighting window. That depends on fixing issue 3.
- A one-page "QLab user's quick start" (what's the same, what's called something else) would help the main audience.

## Polish pass (19 Nov 2026)

21. **Fixed:** with more than one cue list, the standby card cut its chips short ("TRIAL · 30 DA…"). The header now keeps every chip whole.
22. **Fixed:** when locked, the inspector's number fields and checkboxes looked as editable as ever (only the pop-up menus greyed). The whole inspector now dims while locked.
23. **Fixed:** some warnings, the clip dot and a few labels used the Mac's own orange/green/red instead of the Booth colours.
24. **Fixed:** in Setup → MIDI, OSC, Timecode & Phone Remote the boxes were different widths. They now line up.
25. Lighting is greyed out for this beta (menu item and Light tile say "coming later"; no lighting master, blackout or Ready Check items). Shows with Light cues still open and play them.

## Fine-tooth-comb pass (21 Nov 2026)

26. **Fixed:** with a second display connected, the first video output now uses it automatically (the user's projector "shows up in Display settings, but not in the software"); the mapping window's output list still said "Preview window". It now says "<display> (automatic)".
27. **Fixed:** the debug test and photo runs would have covered a developer's second monitor with a black full-screen output once outputs started choosing the second display by themselves. Test runs never pick a display now.
28. **Checked again (21 Nov 2026):** in light mode the fade inspector's pop-up menus are grey with dark text and read clearly; not seen again.
29. **Fixed:** pasting files copied in Finder now reads them straight from the pasteboard, which carries the sandbox's permission to open them (not yet tried by hand).
30. **Fixed:** once the notarised Triskele had run, macOS kept every other program out of its data folder, so the test runs (which keep their media there) would have failed. Development and test builds are now `app.triskele.Triskele.dev`, with their own folder: tests never touch the installed Triskele's settings, licence or shows.

## Ease-of-use batch (21 Nov 2026)

31. **Fixed:** Help → Triskele Help said "Help isn't available". The guide is in the app now, searchable (⌘?), and Help → Send Feedback… emails us with today's log.
32. **Fixed:** ⌘, did nothing. There's one Settings window; each part says whether it's kept with the show, the venue or this Mac.
33. **Fixed:** the audio interface was only in the title bar. It's also in the sound inspector's Outputs, Ready Check and Settings → Audio.
34. **Fixed:** toolbar buttons and the cue-type strip were unlabelled icons (VoiceOver couldn't read the strip).
35. **Fixed:** the first Space in a new show fired cue 2 (the standby was on the last file added).
36. **Fixed:** "MSC GO cue 1: there's no cue 1" on an empty show. Messages name the device, and an empty show stays quiet.
37. **Fixed:** the stage was fixed at 1920 × 1080, so blended projectors were stretched; it's a venue setting now.
38. **Fixed:** Auto-Align with a webcam was off: lens correction, locked exposure/focus, and a quality report. Not yet tried with a real camera.
39. Still to do: lighting playback faders and pages, a fixture editor, effects on beam and colour with tap tempo, blind and preview for lighting cues.


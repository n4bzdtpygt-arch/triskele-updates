# Lighting

> **Not in this beta.** Lighting is greyed out in this first beta (the menu item and the Light cue tile say "coming later"). This page describes it as it will be.

Triskele's lighting works the way a ChamSys console does (patch, groups, palettes, tracking cues, times per attribute) but you work by pointing at lights on a stage plan and dragging lines, not with console buttons. Light cues sit in the same cue list as sound and video and fire on the same GO.

Open it with **Setup → Lighting…** (⌥⌘J).

> Lighting is new. It has passed its tests on this Mac but hasn't driven real lights yet. Try it with the DMX output off first.

## 1. Patch your lights

In the **Patch** tab, click **Add Fixtures**: choose the kind of light, how many, the first light number, the universe and the start address (left empty, Triskele uses the next free address). Clashing addresses are flagged.

**Fixtures that aren't in the list:** the built-in library (the Open Fixture Library) is far from complete for professional moving lights. Most makers publish **GDTF** files for their fixtures (on GDTF Share, gdtf-share.com, or their own websites). Download the .gdtf file, click **Import GDTF…** at the top of Add Fixtures, and every mode of that fixture appears in the list, marked GDTF. Imported fixtures stay in this Mac's library; a show that uses one carries it, so the show opens whole on another Mac. Right-click an imported fixture to remove it from this Mac.

**Big rigs:** you can add up to 999 lights at a time, across up to 64 universes. When a universe fills up, the rest carry on into the next one (100 spots at 16 channels each fill universes 1 to 4), and every universe you use gets a row in the DMX Output tab. A rig of 500 or more lights runs as smoothly as a small one.

When you patch, Triskele makes **ready-made palettes and groups** for you:
- **Colours**: White, Warm white, Red, Orange, Amber, Yellow, Green, Cyan, Blue, Lavender, Magenta, Pink, mixed correctly for each kind of light (RGB, RGBW, CMY).
- **Positions** for moving lights: Home, Centre stage, Downstage centre, Upstage centre, Stage left, Stage right. These are spots on the stage, so each light is aimed from where it hangs.
- **Colour wheels**: for lights with a colour wheel and no colour mixing, the colours above land on the nearest colour on the wheel (White on the open slot), and every other colour on the wheel gets a palette of its own, named as the maker names it ("CTB", "Congo Blue").
- **Beams**: Open (wheels to their open slot), Closed, Frost, and **a palette for every gobo**, named as the maker names it ("Eclipse", "Fan").

Wheel colours and gobo names come from the fixture data (the built-in library or a GDTF file), as ChamSys MagicQ makes its auto palettes.
- **Groups**: "All …" for each kind of light you have two or more of.

**Lights hung the other way round:** right-click lights in the patch list → **Invert Pan**, **Invert Tilt** or **Swap Pan and Tilt**. Triskele turns the values round as the DMX goes out, so palettes, cues and aiming on the plan stay right without reprogramming. The patch list shows "pan ↺", "tilt ↺" or "pan⇄tilt" beside the type.

**Park:** right-click → **Park at What's on Stage** (or select lights and type `park`, or `5 @ 30 park`) holds a light where it is, whatever cues and the programmer do: a work light, a faulty channel, a special that must stay. Parked values show in red with a P in the fixture sheet and "parked" in the patch list. `unpark` lets the selected lights go, `unpark all` every light. The grand master and blackout still apply. Park is saved with the show.

### Importing a rig

**Patch → Import Rig…** reads a rig someone else drew and patches it in one step (one undo):

- **MVR** (My Virtual Rig, exported by Vectorworks, Capture, grandMA3 and others): every light's exact type (from the GDTF files inside), its place in 3D, its channel and its address. The best route when the designer can export it.
- **A Vectorworks ↔ Lightwright data exchange file** (XML): one record per light, whatever the fields are called (Channel, Unit Number, Inst Type, Position, Absolute Address, Color, Purpose…), as elements or attributes.
- **A patch sheet** (CSV or tab-separated, from Lightwright or a spreadsheet): columns are found by their headings: Channel, Address (or Dimmer, "1/101" or "357"), Universe, Position, Unit, Instrument Type, Mode, Color, Purpose. Positions come in 1.5 m apart, to drag into place.
- **Lighting paperwork as PDF**: an instrument schedule or channel hookup printed from Lightwright (or anything laid out the same way: a heading row naming the columns, a row per light). Every light comes in with its position, unit number, type, channel, colour, purpose and address (from the dimmer number when there's no address column). Ditto marks ("), a second light on the same channel and wrapped cells are understood. When one PDF holds several reports listing the same lights, the instrument schedule is used. This is the most reliable route for a venue's rep plot: venues publish this paperwork even when their plot PDF has no readable text.
- **A lighting plot PDF** exported from the drawing program: Triskele reads the **instrument key** (each type and how many), the **hanging positions** (electrics, booms, trusses, FOH) with their real distances from the drawing's scale and the plaster line, and the centre line. Where the plot draws channel numbers in a colour of their own (the legend's "Channel" in red, say, and "Dimmer" in green), every light is read off the drawing instead: one per channel number, with the dimmer beside it, the nearest position label, and its type when the symbol says it ("10°", "wfl"). Otherwise which light hangs where is drawn as symbols, not words, so the lights come in unhung: select them and use **Hang on**. A scanned plot has no text to read: ask for the PDF export, an MVR or a patch sheet.

Before anything is patched, the sheet lists every type with what it was matched to: a tick for a sure match, a question mark for a guess, a warning for none. **Change…** searches the library, or makes it a dimmer (conventional lights such as Source 4s, PARs and zip strips are dimmers automatically), or leaves those lights out.

### Exporting a rig

**Patch → Export Rig** saves the rig for the crew, the venue or another program:

- **Plot (PDF)**: the stage from above at a standard scale (1:25 to 1:200, whichever fits the paper), every bar and boom by name with its height, and every light as a symbol for its kind (profile, fresnel, PAR, LED wash, moving light, batten, strobe, hazer), with its unit number inside, its channel in a blue circle at the lens end, its address ("1/101") in red past that and its gel in green beside it. Boom lights stand in a column beside their boom. A key lists each type and how many (types that share a shape get a small mark, like the beam-angle marks on profiles), a "Typical" box says what each number is, and the title block gives the show, scale, date and a scale bar. Choose the paper under **Plot Paper** (A3 or Tabloid by default, A4 and Letter too).
- **Channel Hookup** and **Instrument Schedule (PDF)**: Lightwright-style paperwork. The hookup lists every light in channel order; the schedule goes position by position in unit order. Paper size under **Paperwork Paper**.
- **Patch Sheet (CSV)**: one row per light with channel, universe, address, position, unit, type, colour, maker, model, mode, purpose and its exact place. Lightwright, Vectorworks and spreadsheets read it, and Triskele reads it back exactly.
- **MVR**: for Vectorworks, Capture, grandMA3, ChamSys and anything else that opens My Virtual Rig: every light's exact place and turn, address, channel and unit, on its hanging position, with a GDTF fixture file for each model (its modes, channels, resting values, pan and tilt range, colour and gobo wheels and lamp commands).

Conventional lights keep what the paperwork called them ("ETC Source Four 26°") and their gel, even though they're patched as dimmers, so exports name them properly. Triskele reads all four back itself; a plot read back gets its channels, addresses and positions, but which type each light is lives in the symbols, so the import notes list the key's types for you to choose.

### The 3D visualiser

**Visualiser** (in the lighting window's top bar, or **Setup → Visualiser…**, ⌥⌘V) opens the 3D view and the stage plan in a **window of their own**, so the programming window keeps its room. The first time, it opens on a second monitor if there is one (never on a display the venue uses for a projector); after that it opens wherever you left it. The **3D** view (and a **3D Visualiser** pane you can put in any view from a pane's title menu) shows the rig in 3D: the stage and house, the bars and booms, and every light with its beam in its live colour and level, aimed by its real pan and tilt (fixed lights point at the stage), with a pool where it lands. It follows the same DMX engine as the outputs, so it shows what your cues do, before you're in the venue. Drag to orbit, scroll or pinch to zoom; **Haze** makes the beams more or less visible; **Front View** goes back to the audience's view. With an imported MVR, lights are where the drawing puts them.

## 2. Place them on the plan

In the **Stage** tab, choose **Move** and drag each light to where it hangs (the audience is at the bottom). This makes the plan match the room and makes the aimed position palettes land in the right place.

### Hanging positions

Lights hang all over a venue: the FOH bridge, balcony fronts, prosc booms, LX bars, the floor. Triskele keeps them in **positions**, so you handle a rig a pen at a time rather than light by light.

- In the inspector's **Positions** section, click **Add Theatre Positions** for a typical set sized to your stage (FOH bridge, balcony front, both prosc booms, LX1–4, floor), plus the house in front of the stage. Or add a **New Bar** or **New Boom** yourself.
- Select some lights, then choose **Hang on → FOH bridge** (or right-click a position). They spread evenly along it at its height, in the order you selected them. A boom stacks them one above another; the plan fans them out sideways so you can see each one.
- **Click a position** (its line or its name) on the plan, or its button in the inspector, to select the lights on it. You can type its name in the command line too: `balcony @ 70`.
- With the **Move** tool, drag a position to move it with all its lights, or drag a bar's end to stretch or turn it (its lights spread out again). Dragging a single light by hand takes it off its position.
- Under **Edit**, set each position's name, whether it's a bar or a boom, and its height. Heights matter: aiming from the balcony or the bridge uses them, so a light out in the house lands where you click on stage.

Set the stage's size (width × depth in metres) at the bottom right of the plan, and the **House** depth (how far the auditorium goes in front of the stage, 0 to hide it); it starts at 12 × 8. **Fit** shows the whole stage and every light. Pinch, ⌘-scroll or use the magnifying glasses to zoom in, and scroll to move around. When lights hang close together, they're drawn smaller so they never overlap, with their numbers shown once you zoom in far enough. With more than 40 moving lights, only the selected ones draw a line to where they point.

## 3. Select lights

- Click a light; ⌘-click or ⇧-click to add more; drag round several to lasso them.
- Click a **group** in the inspector.
- Type in the **command line** at the bottom of the window: `1-8`, `1 thru 10 - 4`, a group name (`front wash`), or a command (`front wash @ 70`).

## 4. Set a look

- **Level**: choose the **Level** tool and drag a light up or down, or use the Level slider in the inspector.
- **Colour**: the colour wheel, a gel, or each channel.
- **Beam**: only the beam controls you've changed show; the rest are under **More**.
- **Position**: choose **Aim** and click or drag on the stage floor; moving lights point there. Or use the pan/tilt pad.
- **Palettes**: click a palette, or drag it onto a light.

### Gels

Lights that mix colour (RGB, RGBW, CMY) can be set to a gel from **Lee, Rosco (Roscolux and Cinegel), Rosco E-Colour+, GAM or Apollo**: about 1,070 colours, mixed as near as their LEDs allow. Open the swatch book from the **Gels** button on the Colour Palettes pane, the **Gel Swatches** pane (choose it from any pane's title menu), or the inspector's Colour section:
- Pick a maker at the top, or All (remembered), and type a number or a name: `201`, `R80`, `G245`, `steel`, `ct blue`. A number alone shows that number from every maker first. Return takes the first match.
- Click a gel to mix it on the selected lights. Hover for its name and how much light it lets through. Right-click it to **keep it as a colour palette**, named after the gel ("L201 Full C.T. Blue"), so cues use it by reference.
- Or type it in the command line: `L201`, `R80`, `E201`, `AP4650`, `lee 201`, `gam 245`, `front wash @ 70 L201`. **GAM needs `gam` or `gel g245`**, because `g 245` is group 245. `gel 201` uses the maker picked in the swatch book.

The colours are the RGB each maker publishes for its gels, gathered by the color-filter-sds project (MIT licence; **Licence** under the swatches). An LED can't make every gel's spectrum, so treat them as a quick way to the right colour, then trim by eye. Dimmers and colour-wheel lights can't take a gel; the command line says so. Diffusion, UV and heat filters aren't in the book. Apollo stopped making gel around 2020, but its numbers still turn up on plots.

What you set is held in the **programmer** and overrides the cues until you **Clear** it (click Clear again to clear the selection too).

### Palette buttons show what's going on
- **Dim**: nothing in it for the selected lights.
- **Bright**: you can use it on the selected lights.
- **Yellow**: the selected lights are already in it (half-yellow: some of them).

Right-click a palette to **select the lights using it**, update it from the selected lights, rename it or delete it.

Cues remember the **palette**, not its numbers: update a palette and every cue that uses it changes. Deleting a palette keeps its values in the cues, so nothing changes on stage.

### The Program view: plotting in one place

The standard **Program** view (⌘1) is laid out like MagicQ's programming screen, with grandMA3's encoder bar:

- **In the middle**, the palette windows: **Groups** and **Colour** on the left, **Position**, **Beam** and **FX** beside them.
- **On the right**, the **keys**, in MagicQ's blocks: programming (**REC**, **UPD**, **CLR**, **BLIND**, **UNDO**, **COPY**, **MOVE**, ⌫), head control (**PREV**, **NEXT**, **ALL**, **HIGHLT**, **ODD**, **EVEN**, **LOCATE**, **FAN**), the attribute and object keys (**GRP**, **INT**, **POS**, **COL**, **BEAM**, **FX**, **CUE**, **REM DIM**; with nothing typed, INT/POS/COL/BEAM switch the encoders) and the keypad. The Mac keyboard types the same lines.
- **Along the bottom of the window**, under the command line, the **encoders**, laid out like Ableton's devices: one device per family the selected lights have (**Intensity**, **Position**, **Colour**, **Beam**), side by side. Each has a title bar (its dot lights in the family's colour when you've set any of it: click the dot to let it go; ↺ sends it home; the chevron folds it away) and a knob per attribute, its name above and its value below (yellow when you've set it). Drag a knob up or down (⇧ or ⌥ for fine), double-click it to send it home. The family you last touched (a palette, or INT/POS/COL/BEAM) is highlighted and brought into view. They're there in every view. The devices share the width of the window; at the right end, the **Programmer** device (as grandMA3 keeps its programming settings at the end of its encoder bar) holds **Fan** (how a change spreads across the selection), **Record** (which of I, P, C, B Record and Update store), the fade **Time** for new cues and **Blind**.

- **Selection tools** along the top of the Groups pool (as MagicQ keeps them on its Group window): **Odd**, **Even**, **1 in 3** (again for the next third), **Invert**, **Reverse** (the order fans and effects follow), **Random** order, **Reselect** (the lights before the last Clear), **On Stage** (every light at 50% or more), **Rem Dim** (everything else to zero) and **Let Go**. Prev, Next and All are on the keys.
- **Groups**: click selects a group, **⇧-click** adds it to the selection, **⌘-click** takes it out, **⌥-click** stores the selected lights as that group.
- **Palettes**: click puts the selected lights in it, **⌥-click** stores or updates it from them, **⌘-click** selects the lights that use it. FX palettes: click runs, ⌥-click stores the programmer's last effect, ⌘-click edits. Macros: click runs, ⌥-click records, ⌘-click edits. (**Record** then a click still works too.)
- **Along the bottom**, one line (⌥⌘D hides or shows it): the **live and next Light cue** with **Go**, **Back**, **Record Cue** and **Update Cue**; **what you've set** (what Record will store, and whether you're in Blind); and the **info line**, which says what anything under the mouse does.
- The **fixture sheet** (all values) is its own view, **Prog** (⌘2), with the keypad; the **cue sheet** and timeline are **Cues** (⌘3). The views bar's order is yours to change.

Other panes you can put in any view:

- **Int · Pos · Col · Beam · FX** (in the Program view, like MagicQ's attribute windows): click **INT**, **POS**, **COL**, **BEAM** or **FX** along its top to show that family's palettes (POS adds the pan/tilt pad, INT the faders). The encoders follow it, as MagicQ's encoders follow the window you're in.
- **Position**: a pan/tilt pad for the selected moving lights. Drag on it to move them (relative, so each keeps its own aim; the fan setting spreads the move; ⇧ or ⌥ for fine, like MagicQ's Shift). Arrows nudge by 1% (⇧ or ⌥: 0.1%). **Flip** takes the other end of pan and tilt, **Mirror** reverses pan only, **Home** sends them back to their resting place, **Locate** makes them easy to find. **Aim on the Plan…** opens the stage plan in the visualiser window: choose **Aim** and click where they should point.
- **Keypad** (like MagicQ's or Eos's): the keys type into the command line with the same words as typing (**1 Thru 5 @ 5 0 Enter** is `1 thru 5 @ 50`), and the line shows what's being built. **Full** and **Out** finish the line at once, as on a console. **/** is time, **Col**/**Pos**/**Beam** palettes, **Cue**, **Group**, **Move**, **Record** (with nothing typed it arms Record), **Update**, **Clear**, **⌫** (back a word or digit), **Last**/**Next** light, **Highlight**, **Locate**, **Home**, **Back** and **Go**. The Mac's keyboard works the same.

## 5. Record a Light cue

Click **Record Cue** (in the lighting window's timeline). A **Light cue** appears in the main cue list, after the standby cue. You can also click **Light** in the cue-type strip.

- A Light cue only stores what it changes. The rest **carries on (tracks)** from the Light cues before it in the same list. Tick **Block** in a cue's Look tab to start afresh from it.
- **Update Cue** adds what you've changed to the Light cue that's live.
- A Light cue's **Look** tab in the main window lists the lights in it (open **Lights in this cue**); the − button takes one out.
- Light cues fire on GO with everything else.
- **Move in Black** (MIB; ChamSys calls it Move When Dark): once a cue has faded, lights it leaves at zero that the **next** Light cue brings up glide to that cue's position, colour and beam while they're dark, so they don't move in view. Each cue sets its own time in the cue sheet's **MIB** column (blank = 3 s; slower is quieter). If you GO the cue before they've finished, those lights stay dark until their move is done, then fade up; LED colour is simply set while they're dark. Untick **MIB** for a cue whose lights should move live (on its own fade).
- **Renumbering**: `move q 5 @ 7` gives Light cue 5 the number 7; `move group 2 @ 5`, `move col 3 @ 9`, `move fx 1 @ 4` do the same for groups and palettes. Everything that uses them keeps working; a number that's taken is refused.
- **Recording onto a cue that's already there** (`record 5` when cue 5 exists) doesn't overwrite it: the line says so. Type `record 5 merge` to add what's set to it, `record 5 replace` to start it again from what's set, or `record 5 remove` to take the lights that are set out of it.

## 6. Timing on the timeline

The timeline under the stage plan shows the Light cues of the cue list on screen:
- the rising line is the **fade in**; drag its end to change it;
- the dashed falling line is the **fade out** for lights going down;
- drag the start to set a **delay**;
- open a cue (chevron) for separate **position, colour and beam** times.

Gobo wheels, colour wheels and prisms don't fade: they jump to their new slot when their fade starts (after any delay), so the audience never sees the wheel roll through the slots in between. Everything else (levels, colour mixing, position, zoom, focus) glides over its time.

⌥-drag for hundredths, ⇧-drag for whole seconds. Click a cue's number to GO from it. The same times are in the cue's **Look** tab in the main window.

## Effects

Select some lights, then **Add Effect** in the inspector:
- **Dimmer**: levels rise and fall in a wave; with spread, a chase along the lights.
- **Flicker**: random flicker for fire, candles or a faulty lamp.
- **Pan sweep / Tilt sweep / Circle**: moving lights move around where they're pointing.
- **Rainbow**: colour-mixing lights run round the colour wheel.
- **Between palettes**: lights step or fade between palettes you pick, in order. Update one of those palettes and the effect follows it.

Each effect is a **device** with knobs. Drag a knob up or down (⌥ for fine), and double-click it to reset.
- **Speed** in beats per minute.
- **Size**: how far it moves the lights.
- **Spread**: 0% moves every light together; 100% spaces them evenly through the cycle, so the effect runs along them in the order you selected them.
- **Width**: how much of the cycle a square or pulse is on, or for palettes how much of each step fades into the next.

Pick the shape with the small waveform buttons: sine, triangle, square, pulse, ramp up, ramp down. The crosshair button moves the effect onto the lights now selected.

### FX palettes

Like ChamSys's FX palettes, an effect can be kept as a palette: its shape, speed, size and spread, without any lights. The **FX Palettes** pool (in the Program view: the attribute window's **FX**) starts with ready-made ones for your rig: **Chase**, **Wave**, **Flicker**, and for moving lights **Circle** and **Pan sweep**, and **Rainbow** for colour mixing.
- Select lights and click one to run it on them (or type `fx 3`, or its name: `spots circle`).
- To keep your own: add an effect, set its knobs, press **Record**, then click a free tile (or type `rec fx 7`).
- Effects run from a palette stay **linked**: right-click the palette → **Edit…** and every cue using it changes, live. Turning a knob on one in the programmer makes it its own effect instead.
- Deleting an FX palette keeps the effect in every cue that uses it, with its last shape (`delete fx 3`).

To change an effect after recording, open the Light cue's **Look** tab in the main window: the same device cards are there, and changes show on stage at once.

**Record Cue** keeps the effects in the Light cue with the look. They carry on through later Light cues, keeping their place in the cycle, until a cue has **Stop effects from earlier cues** ticked (in its Look tab) or **Block**. Effects fade in with the cue's fade and fade out when the cue list is released. **Pause All** holds them where they are.

## Tools

The **Tools** menu (and the **Rem Dim** button) in the top bar:
- **Rem Dim**: every light that isn't selected goes to zero, so you see only these.
- **Odd / Even / Every Third**, **Next Light / Previous Light** (one at a time through the selection) and **Back to All of Them**.
- **Invert Selection**, **Reselect** (what was selected before the last Clear), **Select Lights On Stage** (at 50% or more).
- **Reverse Order / Random Order** of the selection.
- **Let Go of These Lights**: takes them out of the programmer, so cues take them back.
- **Keep Only Lights In** a group.
- **Locate**: full, centred, open white.

Most of these can be typed in the command line, on their own or inside a line (`1 thru 8 odd @ full`): `odd`, `even`, `next`, `prev`, `invert`, `reselect`, `rem dim`, `random`.

### Lamp On, Lamp Off, Reset

Moving lights with a discharge lamp have to be struck before they light, and any moving light can be reset when a motor loses its place. They're for the start and end of the day, not the show, so they live in the **Patch** view. Pick the lights in the patch list, then click **Lamp On**; its arrow has **Lamp Off…** and **Reset**. With nothing picked the button says **Lamp On All…** and asks first, so a big rig is never struck by accident. The button only appears once a light whose fixture data has these commands is patched.

Typed in the command line they act on the selected lights (`spots lamp on`). With nothing selected, or with `all` (`reset all`), they're for the whole rig and ask first: type the same line again within 10 s to do it.

- Triskele sends each light the value its fixture data gives for that command (the Open Fixture Library or the fixture's GDTF file) and holds it as long as the maker says (5 s if the data doesn't say), then lets the channel go back to rest. Lights with no such command in their data are skipped, and the line says how many.
- **Lamp On** strikes lamps half a second apart, so a rig of discharge lamps doesn't strike at once and trip the supply. Reset steps 0.2 s apart.
- **Lamp Off always asks first**, because a hot lamp takes minutes to strike again; so does anything for the whole rig.
- They work during a blackout, aren't recorded in cues and don't touch the programmer. With DMX output off, nothing goes out (the line says so).

**Highlight** shows the selected lights at full, open white so you can see which is which; it's never recorded.

## Macros

A macro is a list of commands that runs from one button, as on ChamSys: a pre-show check, house lights to 30, a reset routine. They live in the **Macros** pool beside the patch (or add the Macros pane to any view).

- **Record one by typing:** type `rec macro 3` (or press **Record** and click a free tile), then type commands as usual; each one runs and is added. Type `wait 5` for a pause. Type `rec macro` again (or press Esc on an empty line) to finish.
- **Or write one:** right-click a tile → **Edit…**: one command per line, `wait 90` for a pause. Lines the command line wouldn't understand are flagged before you save.
- **Run it:** click its tile, or type `macro 3`. Click again (or `stop macro 3`, `stop macros`) to stop it. The message line shows where it's got to.
- A macro that lamps on, lamps off or resets the **whole rig** asks before it starts (typed: the same line again within 10 s). Recording such a line stores it without running it.
- `delete macro 3` deletes one.
- **A Light cue can run a macro**: in the cue's **Look** tab (main window), choose it under **Run macro**. It starts when the cue starts (after its pre-wait), and doesn't track on to later cues. A cue's macro doesn't ask first, even for the whole rig: pressing GO on that cue is the decision. Deleting the macro takes it off the cue.

Example pre-show macro:

```
lamp on all
wait 90
reset all
wait 20
all @ full
wait 10
all @ out
```

## Sending DMX

The **DMX Output** tab sends Art-Net or sACN over the network, and to **USB DMX interfaces**. **It's off until you turn it on**, because DMX sent onto a venue's network can take over their rig. Set each universe's address there and watch the live levels to check before you connect.

**USB:** plug in an interface that speaks the Enttec DMX USB Pro protocol (the Enttec DMX USB Pro and Pro Mk2, DMXking ultraDMX Pro and most "Pro compatible" boxes) and choose it under **USB** for a universe (it shows as cu.usbserial-…; the circular arrow looks again). Nothing needs installing: macOS has the driver. A universe can go out on the network and USB at once. If the interface is unplugged, the line says so and Triskele keeps trying every 2 s, so plugging it back in just works. The plain Enttec Open DMX USB (no "Pro") isn't supported.

## Fog and haze

Patch a hazer or smoke machine from the library (search "hazer" or "fog"; there are generic ones too). Its output is **Fog** and its fan **Fog fan**, beam attributes of their own: type `haze 40` (or `fog 40`, `smoke 40`) and `fan 60`, record them in cues, fade them, put them in palettes and macros. They aren't intensity, so the grand master, blackout, Rem Dim and `all @ full` leave them alone (haze keeps going through a blackout, as on a desk), and they always rest at 0.

## Masters

The lighting window's top bar has the **grand master** and **Blackout**. In the main window, the transport bar has a **Light** master once lights are patched (click its number for blackout), and **Show → Lighting Blackout** is ⌥⇧⌘B. Oh No! (Esc) does **not** touch the lights: a sound panic never blacks out the stage. **Pause All** holds light fades and effects too.

## Typed commands

The command line at the bottom of the lighting window is always ready. It works the way ChamSys MagicQ does: **select, then say what to do**. Press Return to run it, ↑ for the last one, Esc to cancel.

A few short commands run **the moment you type their last key**, with no Return, as MagicQ's FULL does:
- `#` at the end: full. `front #`, `1>6 #`
- `full full`: full (easy to double-tap with your hands on the letters). `front full full`
- `- -` after a level: those lights at that level, every other light to zero. `front @ 50 - -`
- `@@`: select only. `1 thru 4 @@`; `0 @@` selects nothing

They only fire on a key typed at the end of the line: a line brought back with ↑ or pasted in still waits for Return. A single `full` still needs Return, because it might be the start of a longer word, and so does anything with a time (`front @ full / 3`).

**Selecting**
- `1 thru 8` (or `1>8`, or `1-8`), `1 + 3 + 5`, `1 thru 10 - 4`
- `group 2` or `g 2`, `g 1 + g 2`, `all`
- A name: `front wash`, `balcony`, `LX3`, `spots`
- `1 thru` on its own: light 1 and the lights after it of the same type
- `0`: select nothing

**Levels**
- `@ 50` (or `@ 50%`), `@ full` (or `#`, `fl`, or just `full`), `@ out`, `@ half`
- `@ +10`, `@ -10`: up or down from where they are
- `@ 0 thru 100`: spread from the first light to the last

**Palettes and values**
- `c 2`, `p 1`, `b 3`, `i 1`: colour, position, beam and intensity palettes by number
- `red`, `c red`, `colour sunset`: a palette by name
- `red 100 green 20 blue 0`, `zoom 50`, `shutter open`, `iris closed`
- `L201`, `R80`, `E201`, `AP4650`, `lee 201`, `gam 245`, `gel 201`: a gel (GAM needs `gam`: `g` is group)
- `pan -45`, `tilt 30`: in **degrees from centre**, as the fixture sheet shows them; `pan 25%` for a percentage
- `pan -45 thru 45`: spread across the selection

**Time**
- `/ 3` after anything: it fades over 3 s. `1 thru 8 @ full / 3`, `c 2 / 4`
- `5 clear`: let go of everything over 5 s

**Programmer**
- `clear` (again to deselect), `highlight`, `locate`, `blind`, `rem dim`, `odd`, `even`, `next`, `prev`
- `1 thru 2 copy 5 thru 8`; `copy pos col @ group 2` copies only position and colour

**Cues, groups, palettes**
- `fx 3`, `rec fx 3`, `delete fx 3`: FX palettes
- `macro 3`, `rec macro 3` … `rec macro`, `stop macro 3`, `stop macros`, `delete macro 3`, `wait 5` (inside a macro)
- `record`, `record 5`, `record 5 / 3` (with a 3 s fade), `record 5 merge` / `replace` / `remove`, `update`
- `park`, `5 @ 30 park`, `unpark`, `unpark all`
- `go`, `go 5`, `back`, `release`: the Light cues in your cue list
- `rec group 3`, `rec col 4`, `rec pos 2`, `delete q 5`, `delete group 3`, `delete col 4`

Things that are easy to get wrong are caught, with a hint: `1 thru 5 50` asks whether you meant `+ 50` or `@ 50`; `1.5` says light numbers are whole; a word it doesn't know stops the line before anything changes.

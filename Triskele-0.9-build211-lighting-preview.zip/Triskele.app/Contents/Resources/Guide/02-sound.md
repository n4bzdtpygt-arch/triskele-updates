# Sound

## Sound cues

Add sounds by dragging files or folders into the list, clicking **Sound** in the cue-type strip, or **Add Media** in the toolbar, or copy files in Finder (⌘C) and paste them into the list (⌘V). A folder brings in every sound, movie and picture inside it (and its subfolders), in Finder's name order.

Cue names are tidied from the file names: underscores become spaces, and version tags, "final", "copy" and Finder's "(2)" go ("Rain_v3_FINAL.wav" becomes "Rain"). Hover over the cue's name or icon in the inspector to see the file's own name.

**Formats:** anything macOS plays: WAV, AIFF, CAF (16, 24 or 32-bit), MP3, AAC, Apple Lossless, at any sample rate (files at different rates play together; they're converted to the interface's rate as they play). Everything is mixed in 32-bit floating point. The interface in use, and its number of outputs, is at the top left of the window: click it to choose another. **Settings → Audio** (⌘,) has the same choice plus the interface's sample rate, bit depth and buffer size (those belong to the interface, so they're kept on this Mac), names for each output and a test tone per output.

**Numbering from file names** (Cues menu): with it on, "12 Rain.wav" becomes cue 12 "Rain" and files come in in number order.

**Match Loudness of Added Sounds** (Cues menu) evens out new sounds to the same loudness (−23 LUFS). For existing cues: right-click → Match Loudness.

## The Sound tab

- **Level**: the fader goes from silence to +12 dB, with 0 dB three-quarters of the way along. You can also drag the **Level** column in the list up and down (⌥ for fine, ⇧ for 1 dB steps) or double-click it to type.
- **Pan**: left/right.
- **Speed**: 50–200%. With **Keep pitch** on it stretches time; off, the pitch follows like tape. Changes apply from the cue's next GO.
- **Duck other sounds by … dB over … s** (the rubber duck): while this cue plays, every other sound already playing dips by the dB you set (over the time you set) and comes back up when it ends. Good for music under an announcement.
- **Room**: place the sound in the room (see below).
- **Outputs**: the routing grid.

**Several cues at once:** select several rows (⌘-click or ⇧-click) and an inspector change goes to all of them, as one undo step. Dragging the Level column with several rows selected moves them all by the same amount.

## Trim, loops and fades (Trim & Loop tab)

- Drag the **edges of the waveform** to trim the start and end.
- Drag the **round handles** along the top to set a built-in fade in and fade out. Each has a **shape** beside its time in the Trim & Loop tab (linear, S-curve, equal power, exponential); the waveform draws the shape, and while the cue plays a dot rides the line with the level it's at now.
- **Markers:** right-click the waveform → **Add Marker Here**. Markers are numbered green lines; drag one to move it, click it to load the cue there (the next GO or audition starts at it), right-click for **Load to Marker n** or to remove them. They're saved with the cue.
- **Scrub:** hold **⇧** and drag along the waveform to hear it on your headphones (the audition output; never the show's speakers). On a video the frame follows too.
- **Plays** sets how many times it loops; **Loop until devamp** loops until you devamp it (**⌘D** devamps everything looping: each finishes its current pass, then ends).
- **Vamp → Loop only a section**: the intro plays once, the middle section loops, and devamping plays the outro. Drag the ochre VAMP band on the waveform to set it.
- **Zoom** the waveform with a pinch, ⌘-scroll or the corner buttons.
- **Double-click** the waveform to play that cue from there (⌥-double-click to hear it on headphones). **⌥-click** loads the cue to that point, so the next GO starts there.

The same waveform opens under a cue in the list: click its chevron, or press →.

## Fade cues

Click **Fade** in the strip with a cue selected, or drag Fade onto the cue you want to fade. A new fade goes to silence over 3 s and stops the cue at the end.

- **Fade in or out by where it sits:** a fade placed *above* the cue it aims at is a fade in: its GO starts that cue from silence (and, for a picture, invisible) and brings it up to its own level. Placed *below*, it's a fade out. Pick **Do** in the Fade tab (Fade in, Fade out, Fade to a level) to choose yourself; your choice then stays wherever the cue moves.
- **Fade to** a level, and optionally **Pan** or **Routing** (crossfade to different outputs).
- **Curve**: S-curve, linear, equal power (best for crossfades) or exponential.
- **Stop the target** when it ends, or **Fade out and stop everything else** (good for a scene change).
- Aim a fade at a **group** to fade everything playing in it.
- To change what a fade aims at, drag a cue (or a file) onto the middle of the fade row ("Make target").

## Timing: waits and follows

Every cue has a **Pre-wait** (delay before it starts), a **Post-wait**, and a **Then** setting:
- **Do not continue**: wait for the next GO.
- **Auto-continue**: fire the next cue after this one's post-wait.
- **Auto-follow**: fire the next cue when this one finishes.

In the list, drag a wait up or down to change it, and click the follow cell to cycle the three modes. Chains are timed to the sample, so you can build sequences with confidence.

## Groups

Select some cues and click **Group** in the strip. A group can:
- **start everything at once**,
- **play its cues in sequence**, or
- **step through**: a mini cue list. GO enters the group and fires its first cue; each GO after that fires the next one; after the last, the standby moves on.

## Routing to outputs

Choose the interface with the **Interface** menu at the top of the **Outputs** section (one interface for the whole show; it's saved with the show and falls back to the Mac's own output if unplugged). The same choice is in **Settings → Audio**, in **Ready Check** and at the top left of the window. Each row is a channel of the file, each column an output; click to route, drag a lit square up and down to set its level. Click an output number to name it ("Stage L", "Foldback").

**Presets** (above the grid) save a routing and apply it to other cues; right-click several cues → Apply Routing Preset.

## Sounds in the room

Click **Speakers** in the toolbar (top right, next to Mapping), or **Setup → Speakers…** (⌥⌘K), and choose **Room**. Drag each speaker to where it is in the room (stage at the top), set its height, and set the room size. Then in a cue's **Room** section, tick **Place in the room** and drag the dot where the sound should come from. **Spread** blurs it across more speakers.

A fade cue's **Position** moves a placed sound across the room over the fade time.

## Speaker tuning

**Speakers… → Tuning** has, for each output: EQ (up to 8 bands; double-click the curve to add one, drag to move, ⌥-drag for width), delay (in ms and metres), level, mute, and a safety limiter. **Time to…** works out the delay for a delay speaker from where it sits in the room. Tuning is saved with the **venue**, not the show, so a touring show only needs re-tuning in each new room.

## Mic cues

Click **Mic** in the strip. Choose the input device and the input channels in its Input section. A Mic cue is silent until its GO and stays open until stopped; it can be faded, routed, ducked and placed in the room like a sound. The inspector shows the round-trip delay. **Watch for feedback** when a mic is near a speaker.

## Listening on headphones

Pick a headphone output in **Setup → Audition Output**. Then **⇧⌘A** (or the headphones button in the inspector) plays the standby cue there, never through the show's speakers.

## Checking the speakers

**Setup → Speaker & Projector Check…** plays pink noise on one output at a time (or steps through them all) at a level you set.
